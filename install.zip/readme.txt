Import the viking.sql into your database
Copy both install.php and database.sql into the /login folder
Go to http://domain.com/login/install.php

Default login is admin admin