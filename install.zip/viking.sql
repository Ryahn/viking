/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 100113
Source Host           : localhost:3306
Source Database       : vas

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-08-08 23:33:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for attendances
-- ----------------------------
DROP TABLE IF EXISTS `attendances`;
CREATE TABLE `attendances` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `platoon` varchar(255) NOT NULL,
  `is_present` tinyint(1) NOT NULL,
  `is_training` tinyint(1) NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `approved_by` varchar(255) DEFAULT NULL,
  `approved_on` varchar(255) DEFAULT NULL,
  `month_day` varchar(255) DEFAULT NULL,
  `created_on` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid1` (`user_id`),
  CONSTRAINT `userid1` FOREIGN KEY (`user_id`) REFERENCES `login_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for rosters
-- ----------------------------
DROP TABLE IF EXISTS `rosters`;
CREATE TABLE `rosters` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rank` varchar(255) DEFAULT NULL,
  `platoon` varchar(255) DEFAULT NULL,
  `awards` varchar(255) DEFAULT NULL,
  `promoted_on` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `promoted_last` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `userid` (`user_id`),
  CONSTRAINT `userid` FOREIGN KEY (`user_id`) REFERENCES `login_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `user_id` int(10) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `is_guardian` tinyint(1) NOT NULL,
  `is_nightmare` tinyint(1) NOT NULL,
  `is_viking` tinyint(1) NOT NULL,
  `is_whiskey` tinyint(1) NOT NULL,
  `is_rrd` tinyint(1) NOT NULL,
  `can_update` tinyint(1) NOT NULL,
  `can_delete` tinyint(1) NOT NULL,
  `is_pl` tinyint(1) NOT NULL,
  `is_2ic` tinyint(1) NOT NULL,
  `is_3ic` tinyint(1) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `login_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
